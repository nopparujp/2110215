package model;

public class Packager extends Bot {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		finishedProduct+=1;
		System.out.println("Packaged a product");
	}

}
