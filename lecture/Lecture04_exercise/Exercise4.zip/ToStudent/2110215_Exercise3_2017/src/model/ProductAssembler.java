package model;

public class ProductAssembler extends Bot {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("Assembled a product");
	}

}
