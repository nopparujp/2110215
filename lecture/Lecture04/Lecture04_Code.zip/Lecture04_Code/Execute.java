
public interface Execute {
	void doIt();
}
